"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Route_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Core/Route"));
Route_1.default.get('/test', async ({ view }) => {
    return view.render('welcome');
});
Route_1.default.post('/api/v1/sqs/push/:queue', 'QueuePushersController');
Route_1.default.post('/api/v1/sqs/asyncPush/:queue', 'QueueAsyncPushersController');
Route_1.default.post('/api/v1/sqs/empty/:queue', 'EmptyQueueController');
Route_1.default.get('/api/v1/sqs/info', 'QueueInfoController');
//# sourceMappingURL=routes.js.map