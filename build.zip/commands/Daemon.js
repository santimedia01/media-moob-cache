"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = __importDefault(require("path"));
const https_1 = __importDefault(require("https"));
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const got_1 = __importDefault(require("got"));
const sqs_consumer_1 = require("sqs-consumer");
const FileLoggingService_1 = __importDefault(global[Symbol.for('ioc.use')]("App/Services/FileLoggingService"));
const Env_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Core/Env"));
const queueConfig_1 = global[Symbol.for('ioc.use')]("Contracts/validation/queueConfig");
const BaseCommand_1 = require("../base/BaseCommand");
const logging_1 = global[Symbol.for('ioc.use')]("Config/logging");
const Helpers_1 = global[Symbol.for('ioc.use')]("Adonis/Core/Helpers");
const types_1 = require("@poppinss/utils/build/src/Helpers/types");
const luxon_1 = require("luxon");
class Daemon extends BaseCommand_1.BaseCommand {
    constructor() {
        super(...arguments);
        this.FileLogger = new FileLoggingService_1.default({
            name: 'default',
            winstonConfig: logging_1.fileRotateByDay('AdonisJS.log')
        });
    }
    async run() {
        const { validator } = global[Symbol.for('ioc.use')]("Adonis/Core/Validator");
        const Env = global[Symbol.for('ioc.use')]("Adonis/Core/Env");
        const Drive = global[Symbol.for('ioc.use')]("Adonis/Core/Drive");
        const queueConfigFilePath = path_1.default.join(Env.get('QUEUE_CONFIG_FOLDER'), this.queueConfigFileName.replace('.json', '') + '.json');
        let queueConfig = await Drive.exists(queueConfigFilePath)
            ? await Promise.resolve().then(() => __importStar(require(queueConfigFilePath)))
            : this.finishProcess(`Queue Configuration File not found at ${queueConfigFilePath}`);
        try {
            await validator.validate({ schema: await queueConfig_1.queueConfigSchema(), data: queueConfig });
        }
        catch (errors) {
            this.finishProcess(`Errors in Queue configuration File ${queueConfigFilePath}:`, errors.messages);
        }
        this.FileLogger.addChannels([
            { name: 'daemon', winstonConfig: logging_1.fileRotateByDay('Daemon.log', path_1.default.join(queueConfig.QueueName, 'Daemon - Status')) },
            { name: 'received-requests', winstonConfig: logging_1.fileRotateByDay('Request.log', path_1.default.join(queueConfig.QueueName, 'Requests - Received')) },
            { name: 'processed-requests', winstonConfig: logging_1.fileRotateByDay('Results.log', path_1.default.join(queueConfig.QueueName, 'Requests - Process Results')) },
            { name: 'sqs', winstonConfig: logging_1.fileRotateByDay('SQSConsumer.log', path_1.default.join(queueConfig.QueueName, 'SQS - Consumer Errors')) },
            { name: 'sqs-retries', winstonConfig: logging_1.fileRotateByDay('Retries.log', path_1.default.join(queueConfig.QueueName, 'Requests - Retries')) },
        ]);
        aws_sdk_1.default.config.update({
            region: queueConfig.Credentials?.AWS?.AWSRegion || Env.get('AWS_DEFAULT_REGION'),
            accessKeyId: queueConfig.Credentials?.AWS?.AccessKeyId || Env.get('AWS_SQS_DEFAULT_ACCESS_KEY_ID'),
            secretAccessKey: queueConfig.Credentials?.AWS?.SecretAccessKey || Env.get('AWS_SQS_DEFAULT_SECRET_ACCESS_KEY'),
        });
        this.logger.success('Starting the Daemon, config found and validated...');
        const isQueuePipeline = queueConfig.IsQueuePipeline ?? (queueConfig.IsQueuePipeline = false);
        if (isQueuePipeline) {
            await this.resolveQueuePipeline(queueConfig);
        }
        else {
            const consumer = await this.workQueue(queueConfig, `${queueConfig.QueueUrl}/${queueConfig.QueueName}`);
            consumer.start();
        }
    }
    async resolveQueuePipeline(queueConfig) {
        const resetQueueIteration = () => queueConfig.QueuePipelineStartsAtZero ? -1 : 0;
        let queueIteration = resetQueueIteration();
        let workingMainQueue = true;
        while (true) {
            const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
            if (queueIteration !== resetQueueIteration()) {
                await delay((queueConfig.DelaySecondsBetweenQueueCheck || 2) * 1000);
            }
            queueIteration++;
            const queueUrl = `${queueConfig.QueueUrl}/${queueConfig.QueueName}-${queueIteration}`;
            const extraQueueUrl = queueConfig.ExtraQueue && `${queueConfig.QueueUrl}/${queueConfig.ExtraQueue}-${queueIteration}` || '';
            let queueMessagesCount = await this.getMessageCountFromQueue(workingMainQueue ? queueUrl : extraQueueUrl);
            this.logger.success("Checking " + `${workingMainQueue ? queueConfig.QueueName : queueConfig.ExtraQueue}-${queueIteration}... with ${queueMessagesCount}\n`);
            if (queueMessagesCount === 0) {
                continue;
            }
            if (queueMessagesCount === -1) {
                queueIteration = resetQueueIteration();
                if (queueConfig.ExtraQueueStartHour !== undefined
                    && queueConfig.ExtraQueueEndHour !== undefined
                    && Daemon.getCurrentHour() >= queueConfig.ExtraQueueStartHour
                    && Daemon.getCurrentHour() <= queueConfig.ExtraQueueEndHour) {
                    workingMainQueue = !workingMainQueue;
                }
                continue;
            }
            const recheckPriorityQueueEvery = 10;
            let resolvedMessages = 0;
            const sqs = await new aws_sdk_1.default.SQS();
            for (let i = 0; i < queueMessagesCount; i++) {
                const response = await sqs.receiveMessage({ QueueUrl: workingMainQueue ? queueUrl : extraQueueUrl }).promise();
                if (response.Messages && response.Messages.length > 0) {
                    for await (const message of response.Messages) {
                        const transactionId = Helpers_1.string.generateRandom(15);
                        if (message.ReceiptHandle) {
                            const deleteParams = {
                                QueueUrl: workingMainQueue ? queueUrl : extraQueueUrl,
                                ReceiptHandle: message?.ReceiptHandle,
                            };
                            await sqs.deleteMessage(deleteParams).promise();
                        }
                        await this.resolveQueueMessage(message, queueConfig, transactionId);
                        resolvedMessages++;
                    }
                }
                const firstQueueUrl = this.getFirstQueueUrl(queueUrl);
                if (resolvedMessages > 1
                    && recheckPriorityQueueEvery > 0
                    && queueUrl !== firstQueueUrl
                    && resolvedMessages % recheckPriorityQueueEvery === 0) {
                    const newQueueMessagesCount = await this.getMessageCountFromQueue(firstQueueUrl);
                    console.log('Re-Checking if... Queue Pipeline, with ' + newQueueMessagesCount + ' in ' + firstQueueUrl);
                    if (newQueueMessagesCount > 0) {
                        queueIteration = resetQueueIteration();
                        workingMainQueue = !workingMainQueue;
                        break;
                    }
                }
                if (queueMessagesCount <= resolvedMessages) {
                    break;
                }
            }
        }
    }
    async getMessageCountFromQueue(queueUrl) {
        try {
            const message = await (new aws_sdk_1.default.SQS()).getQueueAttributes({
                QueueUrl: queueUrl,
                AttributeNames: ['ApproximateNumberOfMessages'],
            }).promise();
            return parseInt((message.Attributes && message.Attributes.ApproximateNumberOfMessages) || '-1');
        }
        catch (e) {
            return -1;
        }
    }
    getFirstQueueUrl(queueUrl) {
        const queueUrlChars = Array.from(queueUrl);
        queueUrlChars[queueUrlChars.length - 1] = '1';
        return queueUrlChars.join('');
    }
    async workQueue(queueConfig, queueUrl) {
        let restartRetries = 0;
        const sqsDaemon = sqs_consumer_1.Consumer.create({
            queueUrl,
            sqs: new aws_sdk_1.default.SQS({
                httpOptions: {
                    agent: new https_1.default.Agent({
                        keepAlive: true
                    })
                }
            }),
            handleMessage: async (message) => {
                const transactionId = Helpers_1.string.generateRandom(15);
                await this.resolveQueueMessage(message, queueConfig, transactionId);
            },
        });
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
        const retry = () => {
            sqsDaemon.stop();
            delay(5000).then(() => {
                if (restartRetries < 3) {
                    sqsDaemon.start();
                    console.log("Reiniciando...");
                }
                restartRetries++;
            });
        };
        sqsDaemon.on('error', (err) => {
            this.log('error: ' + err.message, this.LOG_TO.ALL, 'sqs');
            retry();
        });
        sqsDaemon.on('processing_error', (err) => {
            this.log('processing_error: ' + err.message, this.LOG_TO.ALL, 'sqs');
            retry();
        });
        sqsDaemon.on('stopped', () => {
            this.log('stopped ' + queueUrl, this.LOG_TO.ALL, 'sqs');
        });
        return sqsDaemon;
    }
    static getCurrentDate() {
        return luxon_1.DateTime.now().setZone('America/Caracas').toFormat('y-MM-dd');
    }
    static getCurrentHour() {
        return luxon_1.DateTime.now().setZone('America/Caracas').hour;
    }
    async resolveQueueMessage(message, queueConfig, transactionId) {
        if (message.Body) {
            let messages = await JSON.parse(message.Body);
            if (queueConfig.QueueName.includes('fifo')) {
                messages = [await JSON.parse(message.Body)];
            }
            if (!types_1.isArray(messages)) {
                messages = [messages];
            }
            for await (const sqsMessage of messages) {
                let requestSuccess = false;
                let requestResponse;
                try {
                    const body = JSON.stringify(sqsMessage.Request.Body || {});
                    const response = await got_1.default(queueConfig.Job.Request.Url, {
                        method: queueConfig.Job.Request.Method || 'get',
                        headers: queueConfig.Job.Request.Headers || {},
                        body: body,
                        timeout: {
                            request: 60 * 1000 * 10,
                        }
                    });
                    requestSuccess = true;
                    requestResponse = response.body;
                }
                catch (error) {
                    let maxRetries = sqsMessage.Request.RemainingRetries !== 0
                        ? sqsMessage.Request.RemainingRetries || 2
                        : 0;
                    this.log(`Retry needed, error: ${error.message}`, this.LOG_TO.FILE, 'sqs-retries');
                    if (maxRetries > 0) {
                        requestResponse = error.message;
                        const retryMessageData = JSON.stringify({
                            ...sqsMessage,
                            Request: {
                                ...sqsMessage.Request,
                                RemainingRetries: maxRetries - 1,
                            },
                        });
                        await got_1.default(Env_1.default.get('SQS_QUEUE_PUSHER') + `/${queueConfig.QueueName}`, {
                            method: 'POST',
                            body: retryMessageData,
                        }).then((response) => {
                            this.log(`Retry inserted into sqs queue successfully <transactionId:${transactionId}> <MessageId:${message.MessageId}>\nResponse was: ${response.body}`, this.LOG_TO.FILE, 'sqs-retries');
                        }).catch((error) => {
                            this.log(`FAILED to push the message into sqs queue again <transactionId:${transactionId}> <MessageId:${message.MessageId}>\nError: ${error.message}`, this.LOG_TO.FILE, 'sqs-retries');
                        });
                    }
                    else {
                        requestResponse = `Request reached max retries limit. Error: ${error.message}`;
                    }
                }
                if (queueConfig.Job.Notification) {
                    await this.notifyStatus(transactionId, requestSuccess, requestResponse, requestSuccess ? queueConfig.Job.Notification.OkUrl || '' : queueConfig.Job.Notification.NoOkUrl || '');
                }
            }
        }
    }
    async notifyStatus(transactionId, requestSuccess, responseData = {}, notificationUrl) {
        let notificationSuccess = false;
        let notificationResponse = {};
        await got_1.default(notificationUrl)
            .then(response => {
            notificationSuccess = true;
            notificationResponse = response.body;
        })
            .catch(error => {
            notificationResponse = error.message;
        });
        await this.log(`
      Request was <${requestSuccess ? 'sent correctly' : 'failed'}> and Notification<${requestSuccess ? 'OkUrl' : 'NoOkUrl'}> was <${notificationSuccess ? 'sent correctly' : 'failed'}>
      <transactionId:${transactionId}> <notifyUrl:${notificationUrl}>
      Request Response Data = ${JSON.stringify(responseData)}
      Notification Response Data = ${JSON.stringify(notificationResponse)}\n\n`, this.LOG_TO.FILE, 'processed-requests');
    }
}
Daemon.commandName = 'sqs:start';
Daemon.description = 'Starts the daemon in the specified queue';
Daemon.settings = { loadApp: true, stayAlive: true };
__decorate([
    BaseCommand_1.args.string({ description: 'Specify the queue config file in queues-config folder (in .env)' }),
    __metadata("design:type", String)
], Daemon.prototype, "queueConfigFileName", void 0);
exports.default = Daemon;
//# sourceMappingURL=Daemon.js.map