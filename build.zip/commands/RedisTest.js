"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = __importDefault(require("path"));
const FileLoggingService_1 = __importDefault(global[Symbol.for('ioc.use')]("App/Services/FileLoggingService"));
const Redis_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Addons/Redis"));
const queueConfig_1 = global[Symbol.for('ioc.use')]("Contracts/validation/queueConfig");
const BaseCommand_1 = require("../base/BaseCommand");
const logging_1 = global[Symbol.for('ioc.use')]("Config/logging");
class RedisTest extends BaseCommand_1.BaseCommand {
    constructor() {
        super(...arguments);
        this.FileLogger = new FileLoggingService_1.default({
            name: 'default',
            winstonConfig: logging_1.fileRotateByDay('AdonisJS.log')
        });
    }
    async run() {
        this.logger.success('Starting the Daemon, validating configuration...');
        const { validator } = global[Symbol.for('ioc.use')]("Adonis/Core/Validator");
        const Env = global[Symbol.for('ioc.use')]("Adonis/Core/Env");
        const Drive = global[Symbol.for('ioc.use')]("Adonis/Core/Drive");
        const queueConfigFilePath = path_1.default.join(Env.get('QUEUE_CONFIG_FOLDER'), this.queueConfigFileName.replace('.json', '') + '.json');
        let queueConfig = await Drive.exists(queueConfigFilePath)
            ? await Promise.resolve().then(() => __importStar(require(queueConfigFilePath)))
            : this.finishProcess(`Queue Configuration File not found at ${queueConfigFilePath}`);
        try {
            await validator.validate({ schema: await queueConfig_1.queueConfigSchema(), data: queueConfig });
        }
        catch (errors) {
            this.finishProcess(`Errors in Queue configuration File ${queueConfigFilePath}:`, errors.messages);
        }
        try {
            await Redis_1.default.set('nombre1', 'valor1');
            const value = await Redis_1.default.get('nombre1');
            console.log('Redis OK, value:', value);
        }
        catch (error) {
            console.error('Error REDIS:', error);
        }
    }
}
RedisTest.commandName = 'sqs:send';
RedisTest.description = '';
RedisTest.settings = { loadApp: true, stayAlive: true };
__decorate([
    BaseCommand_1.args.string({ description: 'Specify the queue config file in queues-config folder (in .env)' }),
    __metadata("design:type", String)
], RedisTest.prototype, "queueConfigFileName", void 0);
exports.default = RedisTest;
//# sourceMappingURL=RedisTest.js.map