"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseCommand = exports.args = void 0;
const standalone_1 = require("@adonisjs/core/build/standalone");
exports.args = standalone_1.args;
class BaseCommand extends standalone_1.BaseCommand {
    constructor() {
        super(...arguments);
        this.LOG_TO = {
            CONSOLE: '1',
            FILE: '2',
            ALL: '12',
        };
    }
    async log(message, logTo = this.LOG_TO.ALL, logChannel = 'daemon') {
        if (logTo.includes(this.LOG_TO.FILE))
            this.FileLogger.channel(logChannel).info(message);
    }
    finishProcess(errorMessage, context = {}) {
        this.FileLogger.channel().error(errorMessage);
        this.logger.error(errorMessage);
        if (Object.keys(context).length !== 0)
            console.log(context);
        this.exit();
    }
}
exports.BaseCommand = BaseCommand;
//# sourceMappingURL=BaseCommand.js.map