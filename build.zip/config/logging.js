"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileLoggingConfig = exports.fileRotateByDay = exports.fileRotateByMinute = void 0;
const path_1 = __importDefault(require("path"));
const winston_daily_rotate_file_1 = __importDefault(require("winston-daily-rotate-file"));
const Env_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Core/Env"));
function fileRotateByMinute(...fileArgs) {
    return {
        transports: [
            new winston_daily_rotate_file_1.default({
                filename: file(...fileArgs),
                datePattern: 'YYYY-MM-DD HH_mm',
                maxSize: '30m',
            }),
        ],
    };
}
exports.fileRotateByMinute = fileRotateByMinute;
function fileRotateByDay(...fileArgs) {
    return {
        transports: [
            new winston_daily_rotate_file_1.default({
                filename: file(...fileArgs),
                datePattern: 'YYYY-MM-DD',
                maxSize: '30m',
            }),
        ],
    };
}
exports.fileRotateByDay = fileRotateByDay;
function file(fileName = 'AdonisJS.log', subFolder = '', root = Env_1.default.get('LOG_FOLDER')) {
    const logExtension = path_1.default.extname(fileName);
    const timestampedFile = fileName.includes('%DATE%')
        ? fileName
        : fileName.replace(logExtension, `- %DATE%${logExtension}`);
    return path_1.default.join(root, subFolder, timestampedFile);
}
exports.fileLoggingConfig = {
    channels: [],
};
//# sourceMappingURL=logging.js.map