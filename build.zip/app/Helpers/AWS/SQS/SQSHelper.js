"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class SQSHelper {
    constructor(AWSRegion, AWSAccountId) {
        this.AWSRegion = AWSRegion;
        this.AWSAccountId = AWSAccountId;
    }
    queueUrl(queue) {
        return `https://sqs.${this.AWSRegion}.amazonaws.com/${this.AWSAccountId}/${queue}`;
    }
}
exports.default = SQSHelper;
//# sourceMappingURL=SQSHelper.js.map