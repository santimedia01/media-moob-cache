"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const Env_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Core/Env"));
const SQSHelper_1 = __importDefault(global[Symbol.for('ioc.use')]("App/Helpers/AWS/SQS/SQSHelper"));
class QueueInfoController {
    async handle({ request, response }) {
        aws_sdk_1.default.config.update({
            region: Env_1.default.get('AWS_DEFAULT_REGION'),
            credentials: new aws_sdk_1.default.Credentials({
                accessKeyId: Env_1.default.get('AWS_SQS_DEFAULT_ACCESS_KEY_ID'),
                secretAccessKey: Env_1.default.get('AWS_SQS_DEFAULT_SECRET_ACCESS_KEY'),
            }),
        });
        const sqsHelper = new SQSHelper_1.default(Env_1.default.get('AWS_DEFAULT_REGION'), Env_1.default.get('AWS_DEFAULT_ACCOUNT_ID'));
        const attributeOptions = {
            all: [
                'VisibilityTimeout',
                'ApproximateNumberOfMessages',
                'ApproximateNumberOfMessagesNotVisible',
                'ApproximateNumberOfMessagesDelayed',
                'CreatedTimestamp',
                'LastModifiedTimestamp',
                'MaximumMessageSize',
                'MessageRetentionPeriod',
                'ReceiveMessageWaitTimeSeconds',
                'DelaySeconds',
                'ApproximateNumberOfMessagesDelayed',
                'ApproximateNumberOfMessagesNotVisible',
                'KmsDataKeyReusePeriodSeconds',
                'KmsMasterKeyId',
                'Policy',
                'QueueArn',
                'RedrivePolicy',
                'KmsMasterKeyId',
                'KmsDataKeyReusePeriodSeconds',
                'DelaySeconds',
                'ReceiveMessageWaitTimeSeconds',
            ],
            reduced: [
                'VisibilityTimeout',
                'ApproximateNumberOfMessages',
                'ApproximateNumberOfMessagesNotVisible',
                'ApproximateNumberOfMessagesDelayed',
            ],
        };
        const attributeType = request.qs().attributes || 'all';
        const selectedAttributes = attributeOptions[attributeType] || attributeOptions['all'];
        const queueNames = request.qs().queues ? request.qs().queues.split(',') : [];
        if (queueNames.length === 0) {
            return response.status(400).json({
                success: false,
                error: 'Queues Not Specified',
            });
        }
        try {
            const queueData = await Promise.all(queueNames.map(async (queueName) => {
                try {
                    const queueUrl = sqsHelper.queueUrl(queueName);
                    const sqs = new aws_sdk_1.default.SQS();
                    const attributes = await sqs
                        .getQueueAttributes({
                        QueueUrl: queueUrl,
                        AttributeNames: selectedAttributes,
                    })
                        .promise();
                    return {
                        success: true,
                        queueName: queueName,
                        attributes: attributes.Attributes,
                    };
                }
                catch (error) {
                    return {
                        success: false,
                        queueName: queueName,
                        error: error.message || 'Unknown error',
                    };
                }
            }));
            return response.json({
                success: true,
                data: queueData,
            });
        }
        catch (e) {
            console.log(e);
            return response.status(500).json({
                success: false,
                error: e.message,
            });
        }
    }
}
exports.default = QueueInfoController;
//# sourceMappingURL=QueueInfoController.js.map