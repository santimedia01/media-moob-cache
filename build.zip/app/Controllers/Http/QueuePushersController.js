"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const Env_1 = __importDefault(global[Symbol.for('ioc.use')]("Adonis/Core/Env"));
const SQSHelper_1 = __importDefault(global[Symbol.for('ioc.use')]("App/Helpers/AWS/SQS/SQSHelper"));
class QueuePushersController {
    async handle({ params, request, response }) {
        aws_sdk_1.default.config.update({
            region: Env_1.default.get('AWS_DEFAULT_REGION'),
            credentials: new aws_sdk_1.default.Credentials({
                accessKeyId: Env_1.default.get('AWS_SQS_DEFAULT_ACCESS_KEY_ID'),
                secretAccessKey: Env_1.default.get('AWS_SQS_DEFAULT_SECRET_ACCESS_KEY'),
            }),
        });
        const sqsHelper = new SQSHelper_1.default(Env_1.default.get('AWS_DEFAULT_REGION'), Env_1.default.get('AWS_DEFAULT_ACCOUNT_ID'));
        try {
            const sqsParams = {
                QueueUrl: sqsHelper.queueUrl(params.queue),
                MessageBody: JSON.stringify(request.all()),
            };
            const sqsResponse = await new aws_sdk_1.default.SQS().sendMessage(sqsParams).promise();
            response.json({
                success: true,
                messageId: sqsResponse.MessageId,
            });
        }
        catch (e) {
            console.log(e);
            response.status(400).json({
                success: false,
                error: e.message,
            });
        }
    }
}
exports.default = QueuePushersController;
//# sourceMappingURL=QueuePushersController.js.map