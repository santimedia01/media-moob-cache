"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const winston_1 = require("winston");
const { combine, timestamp, printf } = winston_1.format;
class FileLoggerService {
    constructor(channelsConfig = []) {
        this.channels = [];
        this.addChannels(channelsConfig);
    }
    addChannels(channelsConfiguration) {
        const channelsConfigs = Array.isArray(channelsConfiguration)
            ? channelsConfiguration
            : [channelsConfiguration];
        channelsConfigs.forEach((channel) => {
            this.channels[channel.name] = this.addChannel(channel.winstonConfig);
        });
    }
    addChannel(winstonConfig) {
        const defaultFormat = printf(({ level, message, timestamp }) => {
            let formattedMessage = message;
            if (typeof message === 'object')
                formattedMessage = JSON.stringify(message);
            return `${timestamp} [${level}] ${formattedMessage}`;
        });
        if (!winstonConfig.format)
            winstonConfig.format = combine(timestamp(), defaultFormat);
        return winston_1.createLogger(winstonConfig);
    }
    channel(name = 'default') {
        if (name in this.channels) {
            return this.channels[name];
        }
        throw Error(`Channel <${name}> does not exists`);
    }
}
exports.default = FileLoggerService;
//# sourceMappingURL=FileLoggingService.js.map