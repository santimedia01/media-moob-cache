"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.queueConfigSchema = void 0;
async function queueConfigSchema() {
    const { schema } = (await Promise.resolve().then(() => __importStar(global[Symbol.for('ioc.use')]("Adonis/Core/Validator")))).default;
    return schema.create({
        QueueUrl: schema.string(),
        QueueName: schema.string(),
        ExtraQueue: schema.string.optional(),
        ExtraQueueStartHour: schema.number.optional(),
        ExtraQueueEndHour: schema.number.optional(),
        IsQueuePipeline: schema.boolean.optional(),
        QueuePipelineStartsAtZero: schema.boolean.optional(),
        DelaySecondsBetweenQueueCheck: schema.number.optional(),
        Job: schema.object().members({
            Request: schema.object().members({
                Url: schema.string(),
                Method: schema.string.optional(),
                Headers: schema.object.optional().members({}),
            }),
            Notification: schema.object.optional().members({
                OkUrl: schema.string.optional(),
                NoOkUrl: schema.string.optional(),
            }),
        }),
        Credentials: schema.object.optional().members({
            AWS: schema.object.optional().members({
                ForDaemon: schema.object.optional().members({
                    AWS_REGION: schema.string.optional(),
                    ACCESS_KEY_ID: schema.string(),
                    SECRET_ACCESS_KEY: schema.string(),
                }),
            }),
        }),
    });
}
exports.queueConfigSchema = queueConfigSchema;
//# sourceMappingURL=queueConfig.js.map